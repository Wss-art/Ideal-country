/*
 Navicat Premium Data Transfer

 Source Server         : localhost_MYSQL
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : 127.0.0.1:3306
 Source Schema         : zhishidian

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 06/04/2022 15:14:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
 
-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config`  (
  `config_id` int(5) NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '参数配置表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES (1, '主框架页-默认皮肤样式名称', 'sys.index.skinName', 'skin-blue', 'Y', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow');
INSERT INTO `sys_config` VALUES (2, '用户管理-账号初始密码', 'sys.user.initPassword', '123456', 'Y', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '初始化密码 123456');
INSERT INTO `sys_config` VALUES (3, '主框架页-侧边栏主题', 'sys.index.sideTheme', 'theme-dark', 'Y', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '深黑主题theme-dark，浅色主题theme-light，深蓝主题theme-blue');
INSERT INTO `sys_config` VALUES (4, '账号自助-是否开启用户注册功能', 'sys.account.registerUser', 'true', 'Y', 'admin', '2018-03-16 11:33:00', 'admin', '2022-04-06 14:31:33', '是否开启注册用户功能（true开启，false关闭）');
INSERT INTO `sys_config` VALUES (6, '主框架页-菜单导航显示风格', 'sys.index.menuStyle', 'default', 'Y', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '菜单导航显示风格（default为左侧导航菜单，topnav为顶部导航菜单）');

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data`  (
  `dict_code` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int(4) NULL DEFAULT 0 COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 38 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典数据表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------
INSERT INTO `sys_dict_data` VALUES (1, 1, '男', '0', 'sys_user_sex', '', '', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '性别男');
INSERT INTO `sys_dict_data` VALUES (2, 2, '女', '1', 'sys_user_sex', '', '', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '性别女');
INSERT INTO `sys_dict_data` VALUES (4, 1, '显示', '0', 'sys_show_hide', '', 'primary', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '显示菜单');
INSERT INTO `sys_dict_data` VALUES (5, 2, '隐藏', '1', 'sys_show_hide', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '隐藏菜单');
INSERT INTO `sys_dict_data` VALUES (6, 1, '正常', '0', 'sys_normal_disable', '', 'primary', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '正常状态');
INSERT INTO `sys_dict_data` VALUES (7, 2, '停用', '1', 'sys_normal_disable', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '停用状态');
INSERT INTO `sys_dict_data` VALUES (8, 1, '正常', '0', 'sys_job_status', '', 'primary', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '正常状态');
INSERT INTO `sys_dict_data` VALUES (9, 2, '暂停', '1', 'sys_job_status', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '停用状态');
INSERT INTO `sys_dict_data` VALUES (10, 1, '默认', 'DEFAULT', 'sys_job_group', '', '', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '默认分组');
INSERT INTO `sys_dict_data` VALUES (11, 2, '系统', 'SYSTEM', 'sys_job_group', '', '', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统分组');
INSERT INTO `sys_dict_data` VALUES (12, 1, '是', 'Y', 'sys_yes_no', '', 'primary', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统默认是');
INSERT INTO `sys_dict_data` VALUES (13, 2, '否', 'N', 'sys_yes_no', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统默认否');
INSERT INTO `sys_dict_data` VALUES (14, 1, '通知', '1', 'sys_notice_type', '', 'warning', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '通知');
INSERT INTO `sys_dict_data` VALUES (15, 2, '公告', '2', 'sys_notice_type', '', 'success', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '公告');
INSERT INTO `sys_dict_data` VALUES (16, 1, '正常', '0', 'sys_notice_status', '', 'primary', 'Y', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '正常状态');
INSERT INTO `sys_dict_data` VALUES (17, 2, '关闭', '1', 'sys_notice_status', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '关闭状态');
INSERT INTO `sys_dict_data` VALUES (18, 99, '其他', '0', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '其他操作');
INSERT INTO `sys_dict_data` VALUES (19, 1, '新增', '1', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '新增操作');
INSERT INTO `sys_dict_data` VALUES (20, 2, '修改', '2', 'sys_oper_type', '', 'info', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '修改操作');
INSERT INTO `sys_dict_data` VALUES (21, 3, '删除', '3', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '删除操作');
INSERT INTO `sys_dict_data` VALUES (22, 4, '授权', '4', 'sys_oper_type', '', 'primary', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '授权操作');
INSERT INTO `sys_dict_data` VALUES (23, 5, '导出', '5', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '导出操作');
INSERT INTO `sys_dict_data` VALUES (24, 6, '导入', '6', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '导入操作');
INSERT INTO `sys_dict_data` VALUES (25, 7, '强退', '7', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '强退操作');
INSERT INTO `sys_dict_data` VALUES (26, 8, '生成代码', '8', 'sys_oper_type', '', 'warning', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '生成操作');
INSERT INTO `sys_dict_data` VALUES (27, 9, '清空数据', '9', 'sys_oper_type', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '清空操作');
INSERT INTO `sys_dict_data` VALUES (28, 1, '成功', '0', 'sys_common_status', '', 'primary', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '正常状态');
INSERT INTO `sys_dict_data` VALUES (29, 2, '失败', '1', 'sys_common_status', '', 'danger', 'N', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '停用状态');
INSERT INTO `sys_dict_data` VALUES (30, 0, '选择题', '0', 'shiti_type', NULL, NULL, 'Y', '0', 'admin', '2021-03-03 21:52:16', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (31, 1, '判断题', '1', 'shiti_type', '', '', 'Y', '0', 'admin', '2021-03-03 21:52:24', 'admin', '2022-04-06 09:53:58', '');
INSERT INTO `sys_dict_data` VALUES (32, 1, 'A', 'A', 'xuanze_ans', NULL, NULL, 'Y', '0', 'admin', '2021-03-03 21:53:11', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (33, 2, 'B', 'B', 'xuanze_ans', NULL, NULL, 'Y', '0', 'admin', '2021-03-03 21:53:15', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (34, 3, 'C', 'C', 'xuanze_ans', NULL, NULL, 'Y', '0', 'admin', '2021-03-03 21:53:20', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (35, 4, 'D', 'D', 'xuanze_ans', NULL, NULL, 'Y', '0', 'admin', '2021-03-03 21:53:25', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (36, 0, '错误', '0', 'panduanti', NULL, 'danger', 'Y', '0', 'admin', '2022-04-06 09:55:27', '', NULL, NULL);
INSERT INTO `sys_dict_data` VALUES (37, 1, '正确', '1', 'panduanti', NULL, 'info', 'Y', '0', 'admin', '2022-04-06 09:55:34', '', NULL, NULL);

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `dict_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  UNIQUE INDEX `dict_type`(`dict_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '字典类型表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
INSERT INTO `sys_dict_type` VALUES (1, '用户性别', 'sys_user_sex', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '用户性别列表');
INSERT INTO `sys_dict_type` VALUES (2, '菜单状态', 'sys_show_hide', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '菜单状态列表');
INSERT INTO `sys_dict_type` VALUES (3, '系统开关', 'sys_normal_disable', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统开关列表');
INSERT INTO `sys_dict_type` VALUES (6, '系统是否', 'sys_yes_no', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统是否列表');
INSERT INTO `sys_dict_type` VALUES (7, '试题类型', 'shiti_type', '0', 'admin', '2021-03-03 21:51:57', '', NULL, NULL);
INSERT INTO `sys_dict_type` VALUES (8, '选择题答案', 'xuanze_ans', '0', 'admin', '2021-03-03 21:53:03', '', NULL, NULL);
INSERT INTO `sys_dict_type` VALUES (9, '判断题', 'panduanti', '0', 'admin', '2022-04-06 09:55:10', '', NULL, NULL);

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父菜单ID',
  `order_num` int(4) NULL DEFAULT 0 COMMENT '显示顺序',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '请求地址',
  `target` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '打开方式（menuItem页签 menuBlank新窗口）',
  `menu_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `perms` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1160 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '菜单权限表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, '系统管理', 0, 1, '#', '', 'M', '0', '', 'fa fa-gear', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '系统管理目录');
INSERT INTO `sys_menu` VALUES (3, '系统工具', 0, 3, '#', 'menuItem', 'M', '1', '', 'fa fa-bars', 'admin', '2018-03-16 11:33:00', 'admin', '2021-05-07 22:04:55', '系统工具目录');
INSERT INTO `sys_menu` VALUES (100, '用户管理', 1, 1, '/system/user', '', 'C', '0', 'system:user:view', 'fa fa-user-o', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '用户管理菜单');
INSERT INTO `sys_menu` VALUES (101, '角色管理', 1, 2, '/system/role', 'menuItem', 'C', '1', 'system:role:view', 'fa fa-user-secret', 'admin', '2018-03-16 11:33:00', 'admin', '2021-03-04 16:16:58', '角色管理菜单');
INSERT INTO `sys_menu` VALUES (102, '菜单管理', 1, 3, '/system/menu', 'menuItem', 'C', '1', 'system:menu:view', 'fa fa-th-list', 'admin', '2018-03-16 11:33:00', 'admin', '2021-03-04 16:29:19', '菜单管理菜单');
INSERT INTO `sys_menu` VALUES (105, '字典管理', 1, 6, '/system/dict', 'menuItem', 'C', '1', 'system:dict:view', 'fa fa-bookmark-o', 'admin', '2018-03-16 11:33:00', 'admin', '2021-03-04 16:16:51', '字典管理菜单');
INSERT INTO `sys_menu` VALUES (106, '参数设置', 1, 7, '/system/config', 'menuItem', 'C', '1', 'system:config:view', 'fa fa-sun-o', 'admin', '2018-03-16 11:33:00', 'admin', '2021-03-04 16:16:46', '参数设置菜单');
INSERT INTO `sys_menu` VALUES (113, '表单构建', 3, 1, '/tool/build', '', 'C', '0', 'tool:build:view', 'fa fa-wpforms', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '表单构建菜单');
INSERT INTO `sys_menu` VALUES (114, '代码生成', 3, 2, '/tool/gen', '', 'C', '0', 'tool:gen:view', 'fa fa-code', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '代码生成菜单');
INSERT INTO `sys_menu` VALUES (1000, '用户查询', 100, 1, '#', '', 'F', '0', 'system:user:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1001, '用户新增', 100, 2, '#', '', 'F', '0', 'system:user:add', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1002, '用户修改', 100, 3, '#', '', 'F', '0', 'system:user:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1003, '用户删除', 100, 4, '#', '', 'F', '0', 'system:user:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1004, '用户导出', 100, 5, '#', '', 'F', '0', 'system:user:export', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1005, '用户导入', 100, 6, '#', '', 'F', '0', 'system:user:import', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1006, '重置密码', 100, 7, '#', '', 'F', '0', 'system:user:resetPwd', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1007, '角色查询', 101, 1, '#', '', 'F', '0', 'system:role:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1008, '角色新增', 101, 2, '#', '', 'F', '0', 'system:role:add', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1009, '角色修改', 101, 3, '#', '', 'F', '0', 'system:role:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1010, '角色删除', 101, 4, '#', '', 'F', '0', 'system:role:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1011, '角色导出', 101, 5, '#', '', 'F', '0', 'system:role:export', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1012, '菜单查询', 102, 1, '#', '', 'F', '0', 'system:menu:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1013, '菜单新增', 102, 2, '#', '', 'F', '0', 'system:menu:add', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1014, '菜单修改', 102, 3, '#', '', 'F', '0', 'system:menu:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1015, '菜单删除', 102, 4, '#', '', 'F', '0', 'system:menu:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1025, '字典查询', 105, 1, '#', '', 'F', '0', 'system:dict:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1026, '字典新增', 105, 2, '#', '', 'F', '0', 'system:dict:add', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1027, '字典修改', 105, 3, '#', '', 'F', '0', 'system:dict:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1028, '字典删除', 105, 4, '#', '', 'F', '0', 'system:dict:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1029, '字典导出', 105, 5, '#', '', 'F', '0', 'system:dict:export', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1030, '参数查询', 106, 1, '#', '', 'F', '0', 'system:config:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1031, '参数新增', 106, 2, '#', '', 'F', '0', 'system:config:add', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1032, '参数修改', 106, 3, '#', '', 'F', '0', 'system:config:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1033, '参数删除', 106, 4, '#', '', 'F', '0', 'system:config:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1034, '参数导出', 106, 5, '#', '', 'F', '0', 'system:config:export', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1057, '生成查询', 114, 1, '#', '', 'F', '0', 'tool:gen:list', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1058, '生成修改', 114, 2, '#', '', 'F', '0', 'tool:gen:edit', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1059, '生成删除', 114, 3, '#', '', 'F', '0', 'tool:gen:remove', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1060, '预览代码', 114, 4, '#', '', 'F', '0', 'tool:gen:preview', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1061, '生成代码', 114, 5, '#', '', 'F', '0', 'tool:gen:code', '#', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '');
INSERT INTO `sys_menu` VALUES (1062, '课程管理', 0, 2, '#', 'menuItem', 'M', '0', NULL, 'fa fa-cutlery', 'admin', '2021-03-03 21:35:18', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1063, '知识点管理', 0, 3, '#', 'menuItem', 'M', '0', NULL, 'fa fa-bar-chart', 'admin', '2021-03-03 21:35:32', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1064, '试题管理', 0, 4, '#', 'menuItem', 'M', '0', NULL, 'fa fa-book', 'admin', '2021-03-03 21:35:44', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1065, '测验管理', 0, 6, '#', 'menuItem', 'M', '0', NULL, 'fa fa-bookmark', 'admin', '2021-03-03 21:35:55', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1066, '批改中心', 0, 7, '#', 'menuItem', 'M', '0', NULL, 'fa fa-hourglass-half', 'admin', '2021-03-03 21:36:14', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1067, '成绩管理', 0, 7, '#', 'menuItem', 'M', '0', NULL, 'fa fa-pencil-square', 'admin', '2021-03-03 21:45:07', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1098, '试题管理', 1064, 1, '/system/shiti', '', 'C', '0', 'system:shiti:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '试题管理菜单');
INSERT INTO `sys_menu` VALUES (1099, '试题管理查询', 1098, 1, '#', '', 'F', '0', 'system:shiti:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1100, '试题管理新增', 1098, 2, '#', '', 'F', '0', 'system:shiti:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1101, '试题管理修改', 1098, 3, '#', '', 'F', '0', 'system:shiti:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1102, '试题管理删除', 1098, 4, '#', '', 'F', '0', 'system:shiti:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1103, '试题管理导出', 1098, 5, '#', '', 'F', '0', 'system:shiti:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1104, '知识点管理', 1063, 1, '/system/section', '', 'C', '0', 'system:section:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '章节管理菜单');
INSERT INTO `sys_menu` VALUES (1105, '章节管理查询', 1104, 1, '#', '', 'F', '0', 'system:section:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1106, '章节管理新增', 1104, 2, '#', '', 'F', '0', 'system:section:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1107, '章节管理修改', 1104, 3, '#', '', 'F', '0', 'system:section:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1108, '章节管理删除', 1104, 4, '#', '', 'F', '0', 'system:section:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1109, '章节管理导出', 1104, 5, '#', '', 'F', '0', 'system:section:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1110, '考试试题', 1065, 1, '/system/kaoshishiti', 'menuItem', 'C', '1', 'system:kaoshishiti:view', '#', 'admin', '2018-03-01 00:00:00', 'admin', '2021-03-04 15:04:34', '考试试题菜单');
INSERT INTO `sys_menu` VALUES (1111, '考试试题查询', 1110, 1, '#', '', 'F', '0', 'system:kaoshishiti:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1112, '考试试题新增', 1110, 2, '#', '', 'F', '0', 'system:kaoshishiti:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1113, '考试试题修改', 1110, 3, '#', '', 'F', '0', 'system:kaoshishiti:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1114, '考试试题删除', 1110, 4, '#', '', 'F', '0', 'system:kaoshishiti:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1115, '考试试题导出', 1110, 5, '#', '', 'F', '0', 'system:kaoshishiti:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1116, '考试管理', 1065, 1, '/system/kaoshi', '', 'C', '0', 'system:kaoshi:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '考试管理菜单');
INSERT INTO `sys_menu` VALUES (1117, '考试管理查询', 1116, 1, '#', '', 'F', '0', 'system:kaoshi:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1118, '考试管理新增', 1116, 2, '#', '', 'F', '0', 'system:kaoshi:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1119, '考试管理修改', 1116, 3, '#', '', 'F', '0', 'system:kaoshi:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1120, '考试管理删除', 1116, 4, '#', '', 'F', '0', 'system:kaoshi:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1121, '考试管理导出', 1116, 5, '#', '', 'F', '0', 'system:kaoshi:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1122, '学生试卷', 1067, 1, '/system/dajuan', 'menuItem', 'C', '0', 'system:dajuan:view', '#', 'admin', '2018-03-01 00:00:00', 'admin', '2021-03-03 22:56:50', '学生试卷菜单');
INSERT INTO `sys_menu` VALUES (1123, '学生试卷查询', 1122, 1, '#', '', 'F', '0', 'system:dajuan:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1124, '学生试卷新增', 1122, 2, '#', '', 'F', '0', 'system:dajuan:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1125, '学生试卷修改', 1122, 3, '#', '', 'F', '0', 'system:dajuan:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1126, '学生试卷删除', 1122, 4, '#', '', 'F', '0', 'system:dajuan:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1127, '学生试卷导出', 1122, 5, '#', '', 'F', '0', 'system:dajuan:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1128, '课程管理', 1062, 1, '/system/course', '', 'C', '0', 'system:course:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '课程管理菜单');
INSERT INTO `sys_menu` VALUES (1129, '课程管理查询', 1128, 1, '#', '', 'F', '0', 'system:course:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1130, '课程管理新增', 1128, 2, '#', '', 'F', '0', 'system:course:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1131, '课程管理修改', 1128, 3, '#', '', 'F', '0', 'system:course:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1132, '课程管理删除', 1128, 4, '#', '', 'F', '0', 'system:course:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1133, '课程管理导出', 1128, 5, '#', '', 'F', '0', 'system:course:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1134, '学生答题', 1066, 1, '/system/ans', '', 'C', '0', 'system:ans:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '学生答题菜单');
INSERT INTO `sys_menu` VALUES (1135, '学生答题查询', 1134, 1, '#', '', 'F', '0', 'system:ans:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1136, '学生答题新增', 1134, 2, '#', '', 'F', '0', 'system:ans:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1137, '学生答题修改', 1134, 3, '#', '', 'F', '0', 'system:ans:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1138, '学生答题删除', 1134, 4, '#', '', 'F', '0', 'system:ans:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1139, '学生答题导出', 1134, 5, '#', '', 'F', '0', 'system:ans:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1146, '留言管理', 1, 1, '/system/commit', '', 'C', '0', 'system:commit:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '留言管理菜单');
INSERT INTO `sys_menu` VALUES (1147, '留言管理查询', 1146, 1, '#', '', 'F', '0', 'system:commit:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1148, '留言管理新增', 1146, 2, '#', '', 'F', '0', 'system:commit:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1149, '留言管理修改', 1146, 3, '#', '', 'F', '0', 'system:commit:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1150, '留言管理删除', 1146, 4, '#', '', 'F', '0', 'system:commit:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1151, '留言管理导出', 1146, 5, '#', '', 'F', '0', 'system:commit:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1152, '班级管理', 0, 8, '#', 'menuItem', 'M', '0', NULL, 'fa fa-id-badge', 'admin', '2021-05-07 22:04:46', '', NULL, '');
INSERT INTO `sys_menu` VALUES (1153, '班级管理', 1152, 1, '/system/banji', '', 'C', '0', 'system:banji:view', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '班级管理菜单');
INSERT INTO `sys_menu` VALUES (1154, '班级管理查询', 1153, 1, '#', '', 'F', '0', 'system:banji:list', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1155, '班级管理新增', 1153, 2, '#', '', 'F', '0', 'system:banji:add', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1156, '班级管理修改', 1153, 3, '#', '', 'F', '0', 'system:banji:edit', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1157, '班级管理删除', 1153, 4, '#', '', 'F', '0', 'system:banji:remove', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1158, '班级管理导出', 1153, 5, '#', '', 'F', '0', 'system:banji:export', '#', 'admin', '2018-03-01 00:00:00', 'ry', '2018-03-01 00:00:00', '');
INSERT INTO `sys_menu` VALUES (1159, '自我测验', 1065, 3, '/system/kaoshi/ziwo', 'menuItem', 'C', '0', NULL, '#', 'admin', '2022-04-06 14:15:07', '', NULL, '');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(4) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色信息表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '管理员', 'admin', 1, '1', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00', '超级管理员');
INSERT INTO `sys_role` VALUES (2, '学生', 'stu', 2, '2', '0', '0', 'admin', '2018-03-16 11:33:00', 'admin', '2022-04-06 15:06:03', '普通角色');
INSERT INTO `sys_role` VALUES (3, '教师', 'teacher', 3, '1', '0', '0', 'T0001', '2022-04-06 14:29:31', 'admin', '2022-04-06 14:30:52', '');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色和菜单关联表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (2, 1);
INSERT INTO `sys_role_menu` VALUES (2, 1065);
INSERT INTO `sys_role_menu` VALUES (2, 1067);
INSERT INTO `sys_role_menu` VALUES (2, 1116);
INSERT INTO `sys_role_menu` VALUES (2, 1117);
INSERT INTO `sys_role_menu` VALUES (2, 1122);
INSERT INTO `sys_role_menu` VALUES (2, 1123);
INSERT INTO `sys_role_menu` VALUES (2, 1146);
INSERT INTO `sys_role_menu` VALUES (2, 1147);
INSERT INTO `sys_role_menu` VALUES (2, 1148);
INSERT INTO `sys_role_menu` VALUES (2, 1159);
INSERT INTO `sys_role_menu` VALUES (3, 1062);
INSERT INTO `sys_role_menu` VALUES (3, 1063);
INSERT INTO `sys_role_menu` VALUES (3, 1064);
INSERT INTO `sys_role_menu` VALUES (3, 1065);
INSERT INTO `sys_role_menu` VALUES (3, 1066);
INSERT INTO `sys_role_menu` VALUES (3, 1067);
INSERT INTO `sys_role_menu` VALUES (3, 1098);
INSERT INTO `sys_role_menu` VALUES (3, 1099);
INSERT INTO `sys_role_menu` VALUES (3, 1100);
INSERT INTO `sys_role_menu` VALUES (3, 1101);
INSERT INTO `sys_role_menu` VALUES (3, 1102);
INSERT INTO `sys_role_menu` VALUES (3, 1103);
INSERT INTO `sys_role_menu` VALUES (3, 1104);
INSERT INTO `sys_role_menu` VALUES (3, 1105);
INSERT INTO `sys_role_menu` VALUES (3, 1106);
INSERT INTO `sys_role_menu` VALUES (3, 1107);
INSERT INTO `sys_role_menu` VALUES (3, 1108);
INSERT INTO `sys_role_menu` VALUES (3, 1109);
INSERT INTO `sys_role_menu` VALUES (3, 1110);
INSERT INTO `sys_role_menu` VALUES (3, 1111);
INSERT INTO `sys_role_menu` VALUES (3, 1112);
INSERT INTO `sys_role_menu` VALUES (3, 1113);
INSERT INTO `sys_role_menu` VALUES (3, 1114);
INSERT INTO `sys_role_menu` VALUES (3, 1115);
INSERT INTO `sys_role_menu` VALUES (3, 1116);
INSERT INTO `sys_role_menu` VALUES (3, 1117);
INSERT INTO `sys_role_menu` VALUES (3, 1118);
INSERT INTO `sys_role_menu` VALUES (3, 1119);
INSERT INTO `sys_role_menu` VALUES (3, 1120);
INSERT INTO `sys_role_menu` VALUES (3, 1121);
INSERT INTO `sys_role_menu` VALUES (3, 1122);
INSERT INTO `sys_role_menu` VALUES (3, 1123);
INSERT INTO `sys_role_menu` VALUES (3, 1124);
INSERT INTO `sys_role_menu` VALUES (3, 1125);
INSERT INTO `sys_role_menu` VALUES (3, 1126);
INSERT INTO `sys_role_menu` VALUES (3, 1127);
INSERT INTO `sys_role_menu` VALUES (3, 1128);
INSERT INTO `sys_role_menu` VALUES (3, 1129);
INSERT INTO `sys_role_menu` VALUES (3, 1130);
INSERT INTO `sys_role_menu` VALUES (3, 1131);
INSERT INTO `sys_role_menu` VALUES (3, 1132);
INSERT INTO `sys_role_menu` VALUES (3, 1133);
INSERT INTO `sys_role_menu` VALUES (3, 1134);
INSERT INTO `sys_role_menu` VALUES (3, 1135);
INSERT INTO `sys_role_menu` VALUES (3, 1136);
INSERT INTO `sys_role_menu` VALUES (3, 1137);
INSERT INTO `sys_role_menu` VALUES (3, 1138);
INSERT INTO `sys_role_menu` VALUES (3, 1139);
INSERT INTO `sys_role_menu` VALUES (3, 1152);
INSERT INTO `sys_role_menu` VALUES (3, 1153);
INSERT INTO `sys_role_menu` VALUES (3, 1154);
INSERT INTO `sys_role_menu` VALUES (3, 1155);
INSERT INTO `sys_role_menu` VALUES (3, 1156);
INSERT INTO `sys_role_menu` VALUES (3, 1157);
INSERT INTO `sys_role_menu` VALUES (3, 1158);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `login_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录账号',
  `user_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '用户类型（00系统用户 01注册用户）',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '头像路径',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '盐加密',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime(0) NULL DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `role_id` int(11) NULL DEFAULT NULL,
  `bid` int(11) NULL DEFAULT NULL COMMENT '班级',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户信息表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', 'admin', '00', 'ry@163.com', '15888888888', '1', '', '828712444e0696adf6ee5e0c7d1e41bf', '838708', '0', '0', '127.0.0.1', '2022-04-06 15:13:01', 'admin', '2018-03-16 11:33:00', 'ry', '2022-04-06 15:13:01', '管理员', 1, NULL);
INSERT INTO `sys_user` VALUES (2, 'ry', 'ry', '00', 'ry@qq.com', '15666666666', '1', '', '8e6d98b90472783cc73c17047ddccf36', '222222', '0', '0', '127.0.0.1', '2020-12-02 23:38:25', 'admin', '2018-03-16 11:33:00', 'ry', '2020-12-02 23:38:25', '测试员', 2, 1);
INSERT INTO `sys_user` VALUES (4, '1001', '张三', '00', '', '', '0', '', '3791c87a3172755a95a794fbc4a4f196', '15c160', '0', '0', '', NULL, '', '2021-03-03 23:41:14', '', NULL, NULL, NULL, 1);
INSERT INTO `sys_user` VALUES (5, '1002', '张三', '00', '1678735375@qq.com', '17756123216', '0', '', '8ce8731051f68722dd40c8c6c5942496', 'aa5f2e', '0', '0', '127.0.0.1', '2022-04-06 15:05:20', '', '2021-03-04 16:31:03', '', '2022-04-06 15:05:20', NULL, 2, 1);
INSERT INTO `sys_user` VALUES (11, '1004', '李四', '00', '123@qq.com', '18733830322', '0', '', '4f5e465773b0d2ac34fed2a2cb8004c3', '4de6f5', '0', '0', '', NULL, 'admin', '2021-03-04 17:09:31', '', NULL, NULL, 2, 1);
INSERT INTO `sys_user` VALUES (12, '2002', '张三', '00', '', '17756174367', '0', '', 'edbbea08b799d6e0049c9d905a7f626f', '773162', '0', '0', '', NULL, '', '2021-05-07 22:39:14', '', NULL, NULL, 2, 1);
INSERT INTO `sys_user` VALUES (13, '20003', '李明', '00', '', '18733332222', '0', '', 'a9f06b01fe1b3c755b31f4f282dcce8b', 'ed91e5', '0', '0', '127.0.0.1', '2022-04-06 09:39:06', '', '2021-05-07 22:48:35', '', '2022-04-06 09:39:06', NULL, 2, 1);
INSERT INTO `sys_user` VALUES (14, 'T0001', '张老师', '00', '161275@qq.com', '17756223216', '0', '', '9d75a71584d7888338b33ee74ee82fdc', '7f9f63', '0', '0', '127.0.0.1', '2022-04-06 14:30:33', '', '2022-04-06 14:26:39', '', '2022-04-06 14:30:33', '', 3, NULL);
INSERT INTO `sys_user` VALUES (15, 'user1', '张三', '01', '', '', '0', '', '4730ab7df7754233f20915c6ae42cb5c', '26e63f', '0', '0', '127.0.0.1', '2022-04-06 14:32:31', '', '2022-04-06 14:32:28', '', '2022-04-06 14:32:31', NULL, 2, NULL);
INSERT INTO `sys_user` VALUES (16, 'T002', '王老师', '01', '', '', '0', '', '4bec4c97b2ec7945afc6fbe07034c98d', 'd61c17', '0', '0', '127.0.0.1', '2022-04-06 15:09:23', '', '2022-04-06 14:56:48', '', '2022-04-06 15:09:23', NULL, 3, NULL);
INSERT INTO `sys_user` VALUES (17, 'S001', '刘答', '01', '', '', '0', '', '5b9a2b115e7baaebaffdbbb7cb195a6c', '2524c6', '0', '0', '', NULL, '', '2022-04-06 14:57:40', '', NULL, NULL, 2, NULL);

-- ----------------------------
-- Table structure for sys_user_online
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_online`;
CREATE TABLE `sys_user_online`  (
  `sessionId` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户会话id',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录账号',
  `dept_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `ipaddr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '在线状态on_line在线off_line离线',
  `start_timestamp` datetime(0) NULL DEFAULT NULL COMMENT 'session创建时间',
  `last_access_time` datetime(0) NULL DEFAULT NULL COMMENT 'session最后访问时间',
  `expire_time` int(5) NULL DEFAULT 0 COMMENT '超时时间，单位为分钟',
  PRIMARY KEY (`sessionId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '在线用户记录' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user_online
-- ----------------------------
INSERT INTO `sys_user_online` VALUES ('5634b765-3f6c-4ffd-829e-62f5f5f0f40b', 'admin', NULL, '127.0.0.1', '内网IP', 'Chrome 9', 'Windows 10', 'on_line', '2022-04-06 15:05:37', '2022-04-06 15:05:42', 1800000);

-- ----------------------------
-- Table structure for t_ans
-- ----------------------------
DROP TABLE IF EXISTS `t_ans`;
CREATE TABLE `t_ans`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `shijuan_id` int(11) NULL DEFAULT NULL COMMENT '试卷',
  `shiti_id` int(11) NULL DEFAULT NULL COMMENT '试题',
  `ans` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '答案',
  `res` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '结果',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '学生答题' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_ans
-- ----------------------------
INSERT INTO `t_ans` VALUES (1, 1, 2, 'A', '1.0', NULL);
INSERT INTO `t_ans` VALUES (2, 1, 10, 'B', '0.0', NULL);
INSERT INTO `t_ans` VALUES (3, 1, 11, 'C', '0.0', NULL);
INSERT INTO `t_ans` VALUES (4, 1, 6, 'D', '1.0', NULL);
INSERT INTO `t_ans` VALUES (5, 1, 7, '1', '1.0', NULL);
INSERT INTO `t_ans` VALUES (6, 1, 14, '1', '0.0', NULL);
INSERT INTO `t_ans` VALUES (7, 2, 1, 'A', '1.0', NULL);
INSERT INTO `t_ans` VALUES (8, 2, 7, '1', '1.0', NULL);
INSERT INTO `t_ans` VALUES (9, 3, 17, 'B', '0.0', NULL);
INSERT INTO `t_ans` VALUES (10, 3, 20, '1', '1.0', NULL);
INSERT INTO `t_ans` VALUES (11, 4, 30, 'A', '0.0', '马虎');
INSERT INTO `t_ans` VALUES (12, 4, 31, '1', '0.0', NULL);
INSERT INTO `t_ans` VALUES (13, 5, 30, 'C', '1.0', NULL);
INSERT INTO `t_ans` VALUES (14, 5, 31, '0', '1.0', NULL);

-- ----------------------------
-- Table structure for t_banji
-- ----------------------------
DROP TABLE IF EXISTS `t_banji`;
CREATE TABLE `t_banji`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '班级',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '班级管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_banji
-- ----------------------------
INSERT INTO `t_banji` VALUES (1, '初一');
INSERT INTO `t_banji` VALUES (2, '初二');
INSERT INTO `t_banji` VALUES (3, '初三');

-- ----------------------------
-- Table structure for t_commit
-- ----------------------------
DROP TABLE IF EXISTS `t_commit`;
CREATE TABLE `t_commit`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '留言',
  `reply` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '回复',
  `create_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '留言管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_commit
-- ----------------------------
INSERT INTO `t_commit` VALUES (2, '123333', NULL, '1001', '2021-03-04 16:03:41');
INSERT INTO `t_commit` VALUES (3, '12222', '2222', '1002', '2021-03-04 16:35:20');
INSERT INTO `t_commit` VALUES (4, '大叔大婶', '反反复复', '1002', '2022-04-06 15:06:57');
INSERT INTO `t_commit` VALUES (5, '对对对', NULL, '1002', '2022-04-06 15:07:44');

-- ----------------------------
-- Table structure for t_course
-- ----------------------------
DROP TABLE IF EXISTS `t_course`;
CREATE TABLE `t_course`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) NULL DEFAULT NULL COMMENT '班级',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '课程管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_course
-- ----------------------------
INSERT INTO `t_course` VALUES (4, 1, '有理数', '123');
INSERT INTO `t_course` VALUES (5, 1, '一元一次方程', '');
INSERT INTO `t_course` VALUES (6, 2, '一次函数', '');
INSERT INTO `t_course` VALUES (7, 3, '全等三角形', '');

-- ----------------------------
-- Table structure for t_dajuan
-- ----------------------------
DROP TABLE IF EXISTS `t_dajuan`;
CREATE TABLE `t_dajuan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `kid` int(11) NULL DEFAULT NULL COMMENT '试卷',
  `score` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '成绩',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `create_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '学生',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '答题时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '学生试卷' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_dajuan
-- ----------------------------
INSERT INTO `t_dajuan` VALUES (1, 8, '3.0', NULL, '1002', '2022-04-06 13:27:35');
INSERT INTO `t_dajuan` VALUES (2, 9, '2.0', NULL, '1002', '2022-04-06 14:23:00');
INSERT INTO `t_dajuan` VALUES (3, 12, '1.0', NULL, '1002', '2022-04-06 14:23:53');
INSERT INTO `t_dajuan` VALUES (4, 13, '0.0', NULL, '1002', '2022-04-06 15:07:57');
INSERT INTO `t_dajuan` VALUES (5, 14, '2.0', NULL, '1002', '2022-04-06 15:08:39');

-- ----------------------------
-- Table structure for t_kaoshi
-- ----------------------------
DROP TABLE IF EXISTS `t_kaoshi`;
CREATE TABLE `t_kaoshi`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `course_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '课程',
  `section_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '章节',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '是否启用',
  `create_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '考试管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_kaoshi
-- ----------------------------
INSERT INTO `t_kaoshi` VALUES (1, '4', '9', '11', 'N', 'admin', '2021-03-03 23:00:40');
INSERT INTO `t_kaoshi` VALUES (2, '4', '8', '第一次考试', 'Y', 'admin', '2021-03-03 23:18:28');
INSERT INTO `t_kaoshi` VALUES (3, '5', '11', '第一次测试', 'Y', 'admin', '2021-03-04 17:12:56');
INSERT INTO `t_kaoshi` VALUES (4, '4', '8', '123123', 'Y', 'admin', '2021-05-07 22:29:01');
INSERT INTO `t_kaoshi` VALUES (5, '4', '8', '333333', 'Y', 'admin', '2021-05-07 22:30:23');
INSERT INTO `t_kaoshi` VALUES (7, '4', '9', 'qqqqqq', 'Y', 'admin', '2021-05-07 22:46:28');
INSERT INTO `t_kaoshi` VALUES (8, '4', '8', 'ssss', 'Y', 'admin', '2021-05-07 22:46:51');
INSERT INTO `t_kaoshi` VALUES (9, '4', '8', '自我测试', 'Y', '1002', '2022-04-06 14:18:57');
INSERT INTO `t_kaoshi` VALUES (10, '4', '9', '222', 'Y', '1002', '2022-04-06 14:23:21');
INSERT INTO `t_kaoshi` VALUES (11, '4', '10', '33', 'Y', '1002', '2022-04-06 14:23:39');
INSERT INTO `t_kaoshi` VALUES (12, '5', '11', '3344', 'Y', '1002', '2022-04-06 14:23:48');
INSERT INTO `t_kaoshi` VALUES (13, '5', '12', '方程式测试', 'Y', 'T002', '2022-04-06 15:01:32');
INSERT INTO `t_kaoshi` VALUES (14, '5', '12', '我的测试', 'Y', '1002', '2022-04-06 15:08:29');

-- ----------------------------
-- Table structure for t_kaoshi_shiti
-- ----------------------------
DROP TABLE IF EXISTS `t_kaoshi_shiti`;
CREATE TABLE `t_kaoshi_shiti`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `kid` int(11) NULL DEFAULT NULL COMMENT '考试',
  `sid` int(11) NULL DEFAULT NULL COMMENT '试题',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '考试试题' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_kaoshi_shiti
-- ----------------------------
INSERT INTO `t_kaoshi_shiti` VALUES (1, 2, 4);
INSERT INTO `t_kaoshi_shiti` VALUES (2, 2, 3);
INSERT INTO `t_kaoshi_shiti` VALUES (3, 2, 7);
INSERT INTO `t_kaoshi_shiti` VALUES (4, 2, 6);
INSERT INTO `t_kaoshi_shiti` VALUES (5, 2, 1);
INSERT INTO `t_kaoshi_shiti` VALUES (6, 2, 2);
INSERT INTO `t_kaoshi_shiti` VALUES (7, 2, 5);
INSERT INTO `t_kaoshi_shiti` VALUES (8, 3, 20);
INSERT INTO `t_kaoshi_shiti` VALUES (9, 3, 18);
INSERT INTO `t_kaoshi_shiti` VALUES (10, 3, 22);
INSERT INTO `t_kaoshi_shiti` VALUES (11, 3, 17);
INSERT INTO `t_kaoshi_shiti` VALUES (12, 3, 15);
INSERT INTO `t_kaoshi_shiti` VALUES (13, 3, 28);
INSERT INTO `t_kaoshi_shiti` VALUES (14, 3, 21);
INSERT INTO `t_kaoshi_shiti` VALUES (15, 3, 25);
INSERT INTO `t_kaoshi_shiti` VALUES (16, 3, 26);
INSERT INTO `t_kaoshi_shiti` VALUES (17, 3, 16);
INSERT INTO `t_kaoshi_shiti` VALUES (18, 4, 3);
INSERT INTO `t_kaoshi_shiti` VALUES (19, 4, 11);
INSERT INTO `t_kaoshi_shiti` VALUES (20, 4, 4);
INSERT INTO `t_kaoshi_shiti` VALUES (21, 4, 7);
INSERT INTO `t_kaoshi_shiti` VALUES (22, 4, 14);
INSERT INTO `t_kaoshi_shiti` VALUES (23, 5, 4);
INSERT INTO `t_kaoshi_shiti` VALUES (24, 5, 3);
INSERT INTO `t_kaoshi_shiti` VALUES (25, 5, 13);
INSERT INTO `t_kaoshi_shiti` VALUES (26, 5, 9);
INSERT INTO `t_kaoshi_shiti` VALUES (27, 5, 1);
INSERT INTO `t_kaoshi_shiti` VALUES (28, 5, 10);
INSERT INTO `t_kaoshi_shiti` VALUES (29, 5, 6);
INSERT INTO `t_kaoshi_shiti` VALUES (30, 5, 5);
INSERT INTO `t_kaoshi_shiti` VALUES (31, 5, 12);
INSERT INTO `t_kaoshi_shiti` VALUES (32, 5, 8);
INSERT INTO `t_kaoshi_shiti` VALUES (33, 5, 11);
INSERT INTO `t_kaoshi_shiti` VALUES (34, 5, 2);
INSERT INTO `t_kaoshi_shiti` VALUES (35, 5, 7);
INSERT INTO `t_kaoshi_shiti` VALUES (36, 5, 14);
INSERT INTO `t_kaoshi_shiti` VALUES (37, 8, 2);
INSERT INTO `t_kaoshi_shiti` VALUES (38, 8, 10);
INSERT INTO `t_kaoshi_shiti` VALUES (39, 8, 11);
INSERT INTO `t_kaoshi_shiti` VALUES (40, 8, 6);
INSERT INTO `t_kaoshi_shiti` VALUES (41, 8, 7);
INSERT INTO `t_kaoshi_shiti` VALUES (42, 8, 14);
INSERT INTO `t_kaoshi_shiti` VALUES (43, 9, 1);
INSERT INTO `t_kaoshi_shiti` VALUES (44, 9, 7);
INSERT INTO `t_kaoshi_shiti` VALUES (45, 12, 17);
INSERT INTO `t_kaoshi_shiti` VALUES (46, 12, 20);
INSERT INTO `t_kaoshi_shiti` VALUES (47, 13, 30);
INSERT INTO `t_kaoshi_shiti` VALUES (48, 13, 31);
INSERT INTO `t_kaoshi_shiti` VALUES (49, 14, 30);
INSERT INTO `t_kaoshi_shiti` VALUES (50, 14, 31);

-- ----------------------------
-- Table structure for t_section
-- ----------------------------
DROP TABLE IF EXISTS `t_section`;
CREATE TABLE `t_section`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `course_id` int(11) NULL DEFAULT NULL COMMENT '课程',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '章节',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '章节管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_section
-- ----------------------------
INSERT INTO `t_section` VALUES (8, 4, '正负数');
INSERT INTO `t_section` VALUES (9, 4, '有理数');
INSERT INTO `t_section` VALUES (10, 4, '数轴');
INSERT INTO `t_section` VALUES (11, 5, '等式的性质');
INSERT INTO `t_section` VALUES (12, 5, '方程式');

-- ----------------------------
-- Table structure for t_shiti
-- ----------------------------
DROP TABLE IF EXISTS `t_shiti`;
CREATE TABLE `t_shiti`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `section_id` int(11) NULL DEFAULT NULL COMMENT '章节',
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '类型',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '问题',
  `qa` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '答案A',
  `qb` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '答案B',
  `qc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '答案C',
  `qd` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '答案D',
  `qe` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '主观题答案',
  `ans` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '正确答案',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '试题管理' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_shiti
-- ----------------------------
INSERT INTO `t_shiti` VALUES (1, 8, '0', '这题选什么？', 'A', 'C', 'D', 'B', '', 'A');
INSERT INTO `t_shiti` VALUES (2, 8, '0', '问题一', '2', '3', '4', '5', '', 'A');
INSERT INTO `t_shiti` VALUES (3, 8, '0', '问题一', '2', '2', '2', '2', '', 'D');
INSERT INTO `t_shiti` VALUES (4, 8, '0', '问题一', '3', '3', '3', '3', '', 'D');
INSERT INTO `t_shiti` VALUES (5, 8, '0', '问题一', '4', '4', '4', '4', '', 'D');
INSERT INTO `t_shiti` VALUES (6, 8, '0', '5问题一', '5', '5', '5', '5', '', 'D');
INSERT INTO `t_shiti` VALUES (7, 8, '1', '1+1=2?', NULL, NULL, NULL, NULL, '1', NULL);
INSERT INTO `t_shiti` VALUES (8, 9, '0', '这题选什么？', 'A', 'C', 'D', 'B', '', 'A');
INSERT INTO `t_shiti` VALUES (9, 9, '0', '1问题一', '2', '3', '4', '5', '', 'A');
INSERT INTO `t_shiti` VALUES (10, 9, '0', '2问题一', '2', '2', '2', '2', '', 'D');
INSERT INTO `t_shiti` VALUES (11, 9, '0', '3问题一', '3', '3', '3', '3', '', 'D');
INSERT INTO `t_shiti` VALUES (12, 9, '0', '4问题一', '4', '4', '4', '4', '', 'D');
INSERT INTO `t_shiti` VALUES (13, 9, '0', '5问题一', '5', '5', '5', '5', '', 'D');
INSERT INTO `t_shiti` VALUES (14, 8, '1', '1+1=3?', NULL, NULL, NULL, NULL, '0', NULL);
INSERT INTO `t_shiti` VALUES (15, 11, '0', '问题一', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (16, 11, '0', '问题一116', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (17, 11, '0', '问题二', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (18, 11, '0', '问题三', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (19, 11, '0', '问题四', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (20, 11, '1', '判断题测试', NULL, NULL, NULL, NULL, '1', NULL);
INSERT INTO `t_shiti` VALUES (21, 10, '0', '问题一6', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (22, 10, '0', '问题一7', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (23, 10, '0', '问题一8', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (24, 10, '0', '问题一9', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (25, 10, '0', '问题一14', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (26, 10, '0', '问题一12', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (27, 10, '0', '问题一13', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (28, 10, '0', '问题一116', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (29, 11, '0', '问题一117', '答案A', '答案B', '答案C', '答案D', '', 'A');
INSERT INTO `t_shiti` VALUES (30, 12, '0', '1+2=?', '1', '2', '3', '4', '', 'C');
INSERT INTO `t_shiti` VALUES (31, 12, '1', '2+2=3?', '', '', '', '', '0', '');

SET FOREIGN_KEY_CHECKS = 1;
